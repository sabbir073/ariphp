Class name || input point
<<<<<<<<<<<<<>>>>>>>>>>>>>
accidentnumber || 1
primaryinformationumber || 2
thana || 3
zilla || 4
accidentcarnumber || 5
injureddrivernumber || 6
injuredpassengernumber || 7
injuredpassersbynumber || 8
accidentlevel || 9
sunday || 10
monday || 10
tuesday || 10
wednesday || 10
thursday || 10
friday || 10
saturday || 10
accidentdate || 11,12,13
accidenttime || 14
reporttime || 14
reportdate || 14
accidentlocationtype || 15
trafficcontrolsystem || 16
collisiontype || 17
carmovementdirection || 18
roaddivider || 19
weather || 20
light || 21
roadgeometricinfo || 22
roadsurfacecondition || 23
roadtype || 24
roadcondition || 25
roadclass || 26
roadcharacteristic || 27
areatype || 28
xymap || 29
xaxis || 30
yaxis || 31
route || 32
kilometre || 33
hundredmetre || 34
nodemap || 35
nodeone || 36
nodetwo || 37
cityname || 
distance || 
roadname || 
roadorplace || 
distancetwo || 
roadorplacetwo || 
distancethree || 
roadname2 || 
distancefour || 
accidentsigns || 
collisionsigns || 
accidentsummary || 
nameandaddress || 
nameandaddresstwo || 
nameorrank || 
infoentrydate || 
nameorranktwo || 
infoentrydatetwo || 
nameorrankthree || 
infoentrydatefour || 
lawrulesnumber || 
casesituation || 
vehiclereg || 38
vehicleregextra || 39



vehiclenumber || 53
passengergender || 54
passengerage || 55
passengedamage || 56
passengeplace || 57
activities || 58
vehiclenumberp || 59
passengergenderp || 60
passengeragep || 61
passengedamagep || 62
passengeplacep || 63
activitiesp || 64

accidentreasonone || 65
accidentreasontwo || 66
accidentreasonthree || 67

fitnesscert || 40

checkinsurance ||

vehicletype || 41

vehiclerunningtype || 42

vehicleproductweight || 43

vehicleproblem || 44

vehiclesuffer || 45

drivinglicense || 46

vehicleregextra || 47

licensetype

licenseexpire

drivergender || 48

driverage || 49

driverinjury || 50

isdrunked || 51

sitbeltyes || 52

passengername

walkername

